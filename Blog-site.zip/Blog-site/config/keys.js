//adding this to .gitignore

module.exports = {
    google: {
      clientID:
        "965561535096-0ou574u5duf273fuhgc98l364aqmk7in.apps.googleusercontent.com",
      clientSecret: "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",
    }, 
    session: {
        cookieKey: 'thenetninjaisawesomeiguess'
    }
  };
  

  